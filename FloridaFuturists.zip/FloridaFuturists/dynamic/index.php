<!DOCTYPE html>
<html>
<head>
<title>Florida Futurists | Home</title>
	<!-- include Bootstrap CSS -->
	<link rel="stylesheet" href="public/css/bootstrap.min.css">

     <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="vendor/boxicons/css/boxicons.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="public/css/style.css" rel="stylesheet">

</head>
<!-- Body -->
<body>

	<?php include 'views/partials/header.php'; ?>
	<?php include 'views/partials/home.php'; ?>
	<?php include 'views/partials/footer.php'; ?>


	<!-- include jQuery, Popper.js, and Bootstrap JavaScript -->
	<script src="../public/js/jquery.min.js"></script>
	<script src="../public/js/popper.min.js"></script>
	<script src="../public/js/bootstrap.min.js"></script>
	<!-- include custom JavaScript -->
	<script src="public/js/main.js"></script>

</body>
</html>