  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container-fluid">

      <div class="row justify-content-center">
        <div class="col-xl-9 d-flex align-items-center justify-content-lg-between">
          <h1 class="logo me-auto me-lg-0"><a href="index.html"> Florida Futurists</a></h1>
          <!-- Uncomment to use an image logo -->
          <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

          <nav id="navbar" class="navbar order-last order-lg-0">
            <ul>
          <!--1 Menu Item-->
                        <li><a class="nav-link scrollto active" href="#hero"> News </a></li>

          <!--2 Menu Item-->

          <li class="dropdown"><a href="#"><span> Calendar </span> </a>
                          </li>           
          <!--3 Menu Item-->

                      <li class="dropdown"><a href="#"><span> Membership </span> </a>
                          </li>
                          
          <!--4 Menu Item-->
                        <li class="dropdown"><a href="#"><span>About</span> <i class="bi bi-chevron-down"></i></a>
                          <ul>
                          <li><a href="#"> How to Join </a></li>
                          <li><a href="#"> Our Mission</a></li>
                          <li><a href="#"> Careers / Volunteer </a></li>
                          <li><a href="#"> Rules as a Board Member </a></li>
                          <li><a href="#"> Our Charity - Order of the OSINT Foundation </a></li>

                        </ul>
                        </li>
          <!--5 Menu Item-->
                <li class="dropdown"><a href="#"><span>Futurist Network</span> <i class="bi bi-chevron-down"></i></a>
                  <ul>
                    <li><a href="#">Meet Committed Futurists (A-Z Directory)<i class="bi bi-chevron-right"></i></a></li>
                    <li class="dropdown"><a href="#"><span>Explore Florida Futurists By Region</span> <i class="bi bi-chevron-right"></i></a>
                      <ul>
                        <li><a href="#">Northwest Florida</a></li>
                        <li><a href="#">North Central Florida</a></li>
                        <li><a href="#">Northeast Florida</a></li>
                        <li><a href="#">Centralwest Florida</a></li>
                        <li><a href="#">Central Florida</a></li>
                        <li><a href="#">Centraleast Florida</a></li>
                        <li><a href="#">Southwest Florida</a></li>
                        <li><a href="#">Southeast Florida</a></li>
                        <li><a href="#">Florida Keys</a></li>
                      </ul>
                    </li>          
                  </ul>
                </li>
<!--6 Menu Item-->
                <li class="dropdown"><a href="#"><span> Resources </span> <i class="bi bi-chevron-down"></i></a>
                  <ul>
                    <li><a href="#">Florida's Future Guide</a></li>
                    <li class="dropdown"><a href="#"><span>Quicklink to Florida State Agencies</span> </a></li>          
                    <li><a href="#">Report Cyber Crime with CyberFlorida</a></li>
                    <li><a href="#">Explore Florida Podcasts</a></li>
                    <li><a href="#">Contact Us</a></li>

                  </ul>
                </li>
<!--7 Menu Item-->
              <li class="dropdown"><a href="#"><span>Investors</span> </a>
              </li>
            </ul>
            <i class="bi bi-list mobile-nav-toggle"></i>
          </nav>
<!-- .navbar -->
          <a href="#about" class="get-started-btn scrollto">Join Now</a>
        </div>
      </div>

    </div>
  </header><!-- End Header -->
  
  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

