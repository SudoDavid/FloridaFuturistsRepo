  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center" >
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-xl-8">
          <h1> Uniting Florida Today</h1>
          <h2> For A Brighter America, Tomorrow </h2>
          <a href="#" class="glightbox play-btn mb-4"></a>
        </div>
      </div>
    </div>
  </section><!-- End Hero -->
